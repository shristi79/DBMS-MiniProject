import streamlit as st

st.title("Online Shopping Management System")