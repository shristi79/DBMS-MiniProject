import pandas as pd
import streamlit as st
from database import view_all_data, view_only_products, get_products, edit_product_data


def update():
    result = view_all_data()
    df = pd.DataFrame(result, columns=['product_id', 'product_type', 'age_group', 'size', 'cost', 'quantity', 'seller_id', 'color'])
    with st.expander("Available Products"):
        st.dataframe(df)
    list_of_products = [i[0] for i in view_only_products()]
    selected_product = st.selectbox("Products to Edit", list_of_products)

    selected_result = get_products(selected_product)
    if selected_result:
        product_id = selected_result[0][0]

        col1, col2 = st.columns(2)
        with col1:
            new_product_type = st.text_input("Product_Type:")
            new_age_group = st.text_input("Age_group:")
            new_size = st.text_input("Size:")
        with col2:
            new_cost = st.text_input("Cost:")
            new_quantity = st.text_input("Quantity:")
            new_seller_id = st.text_input("Seller_id:")
            new_color = st.text_input("Color:")

        if st.button("Update Order"):
            edit_product_data(new_product_type, new_age_group, new_size, new_cost, new_quantity, new_seller_id, new_color, product_id)
            st.success("Successfully updated:: {} and ::{}".format(new_product_type, new_age_group, new_size, new_cost, new_quantity, new_seller_id, new_color))
        result2 = view_all_data()
        df2 = pd.DataFrame(result2, columns=['product_id', 'product_type', 'age_group', 'size', 'cost', 'quantity', 'seller_id', 'color'])
        with st.expander("Updated data"):
            st.dataframe(df2)