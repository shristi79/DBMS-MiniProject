import streamlit as st
from database import add_data


def create():
    col1, col2 = st.columns(2)
    with col1:
        product_id = st.text_input("Product_id:")
        product_type = st.text_input("Product_Type:")
        age_group = st.text_input("Age_group:")
        size = st.text_input("Size:")
    with col2:
        cost = st.text_input("Cost:")
        quantity = st.text_input("Quantity:")
        seller_id = st.text_input("Seller_id:")
        color = st.text_input("Color:")
    if st.button("Add Product"):
        add_data(product_id, product_type, age_group, size, cost, quantity, seller_id, color)
        st.success("Successfully added Product details: {}".format(product_id))