import mysql.connector
mydb = mysql.connector.connect(host="localhost", user="root", password="6969")
c = mydb.cursor()
c.execute("USE ecommerce")

import streamlit as st 
from create1 import create
from delete import delete
from read import read
from update import update


def main():
    st.title("Online Shopping Management System")
    menu = ["Add", "View", "Edit", "Remove"]
    choice = st.sidebar.selectbox("Menu", menu)

    if choice == "Add":
        st.subheader("Enter Product Details:")
        create()
    elif choice == "View":
        st.subheader("View Product details")
        read()
    elif choice == "Edit":
        st.subheader("Update Product details")
        update()
    elif choice == "Remove":
        st.subheader("Delete Product")
        delete()
    else:
        st.subheader("About the Product ")


if __name__ == "__main__":
    main()
