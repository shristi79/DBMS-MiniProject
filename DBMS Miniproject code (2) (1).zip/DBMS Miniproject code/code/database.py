import mysql.connector

mydb = mysql.connector.connect(
    host="localhost", user="root", password="6969", database="ecommerce"
)
c = mydb.cursor()

'''
def create_table():
    c.execute('CREATE TABLE IF NOT EXISTS BLOCKS(dealer_id TEXT, dealer_name TEXT, dealer_city TEXT, dealer_pin TEXT, '
              'dealer_street TEXT)')
'''


def add_data(product_id, product_type, age_group, size, cost, quantity, seller_id, color):
    sql = "INSERT INTO PRODUCT (product_id, product_type, age_group, size, cost, quantity, seller_id, color) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
    val = (product_id, product_type, age_group, size, cost, quantity, seller_id, color)
    c.execute(sql, val)
    mydb.commit()


def view_all_data():
    c.execute("SELECT * FROM PRODUCT")
    data = c.fetchall()
    return data


def view_only_products():
    c.execute("SELECT product_id FROM PRODUCT")
    data = c.fetchall()
    return data


def get_products(selected_products):
    sql = "SELECT * FROM PRODUCT WHERE product_id = %s"
    c.execute(sql, (selected_products,))
    data = c.fetchall()
    return data


def edit_product_data(
    new_product_type,
    new_age_group,
    new_size,
    new_cost,
    new_quantity,
    new_seller_id,
    new_color,
    product_id,
):
    sql = "UPDATE PRODUCT SET product_type=%s, age_group=%s, size=%s, cost=%s, quantity=%s, seller_id=%s, color=%s WHERE product_id=%s"
    val = (
        new_product_type,
        new_age_group,
        new_size,
        new_cost,
        new_quantity,
        new_seller_id,
        new_color,
        product_id,
    )
    c.execute(sql, val)
    mydb.commit()


def delete_data(product_id):
    sql = "DELETE FROM PRODUCT WHERE product_id=%s"
    c.execute(sql, (product_id,))
    mydb.commit()
